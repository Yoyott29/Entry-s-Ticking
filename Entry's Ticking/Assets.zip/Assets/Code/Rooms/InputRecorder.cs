using UnityEngine;
using System.Collections.Generic;

public class InputRecorder : MonoBehaviour
{
    public List<QueuedAction> Moves { get; private set; } = new();
    public bool isDone { get; private set; }
    float timer;
    public int maxMoves = 15;

    private GameObject inputSoundObject;

    static readonly Dictionary<KeyCode, Vector2Int> Keymap = new()
    {
        { KeyCode.W, Vector2Int.up },
        { KeyCode.S, Vector2Int.down },
        { KeyCode.A, Vector2Int.left },
        { KeyCode.D, Vector2Int.right }
    };


    void Start()
    {
        inputSoundObject = gameObject.transform.Find("Input Sound").gameObject;
    }

    public void BeginRecording(float duration)
    {
        Moves.Clear();
        timer = duration;
        isDone = false;
    }

    void Update()
    {
        if (isDone)
            return;

        foreach(var keyValue in Keymap)
            if (Input.GetKeyDown(keyValue.Key) && Moves.Count < maxMoves) {
                Manage_Sounds.PlaySFX("Input", inputSoundObject);
                Moves.Add(QueuedAction.MoveAction(keyValue.Value));
            }

        if (Input.GetKeyDown(KeyCode.Space) && Moves.Count < maxMoves)
            Moves.Add(QueuedAction.AttackAction());

        if (Input.GetKeyDown(KeyCode.Backspace) && Moves.Count > 0)
            Moves.RemoveAt(Moves.Count - 1);

        if (Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter)) {
            isDone = true;
            timer = 0f;
            return;
        }

        timer -= Time.deltaTime;
        if (timer <= 0f)
            isDone = true;
    }
}
